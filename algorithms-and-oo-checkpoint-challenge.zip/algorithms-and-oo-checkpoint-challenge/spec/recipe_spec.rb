require_relative "../recipe"

describe Recipe do
end
