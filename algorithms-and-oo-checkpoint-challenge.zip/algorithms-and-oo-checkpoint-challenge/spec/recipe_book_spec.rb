require_relative "../recipe_book"

describe RecipeBook do

  describe "#find_recipe_by_id" do
    xit 'finds a recipe by id' do
    end

    xit "raises an exception if it can't find a recipe" do
      #How do I check exceptions? Here's an example
      # expect { my_thing.method_that_raises }.to raise_error
    end
  end
end
