require 'csv'

class RecipeBook
  attr_reader :recipes 

  def initialize
    @recipes = []
  end

  def load_recipes(filename)
    CSV.table(filename).each do |recipe_data|
      @recipes << Recipe.new(recipe_data) 
    end
  end

  def find_recipe_by_id(recipe_id) #this has a lesson about scope. #the name is bad, named the same as class variable
    found_recipes = []
    @recipes.each do |recipe| 
      found_recipes << recipe if recipe.id == recipe_id.to_i
    end
    raise "Can't find a recipe with an id of #{recipe_id.inspect}" if found_recipes.empty? #don't use unless
    found_recipes
  end

  def display_list # or use a to_s
    @recipes.sort_by do |recipe|
      recipe.name.downcase
    end.each do |recipe|
    puts recipe.title
    # puts "#{recipe.id". #{recipe.name}" # knows way too much about recipe violations of tell don't ask
    end
  end

end#end
