class Recipe #id,name,description,ingredients,directions

	attr_reader :name, :id, :description, :ingredients, :directions

	def initialize(args = {})
		@id = args[:id]
		@name = args[:name]
		@description = args[:description]
		@recipe = args[:recipe]
		@ingredients = args[:ingredients]
		@directions = args[:directions]
	end

	def to_s
<<-STRING
#{id} - #{name}
#{description}

Ingredients:
#{ingredients}

Preparation Instructions:
#{directions}
STRING
	end

	def title #short description
    "#{self.id}. #{self.name}"
  end
end
